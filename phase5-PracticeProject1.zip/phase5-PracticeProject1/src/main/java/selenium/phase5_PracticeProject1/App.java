package selenium.phase5_PracticeProject1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class App {

    public static void main(String[] args) throws InterruptedException {
        // Register the webdriver => browser vendor
        WebDriverManager.chromedriver().setup();
        // Creating an object for the WebDriver
        WebDriver wd = new ChromeDriver();
        // Maximize the browser window
        wd.manage().window().maximize();

        // Login Automation on Amazon
        loginAmazon(wd);

        // Registration Automation on Amazon
        registerAmazon(wd);

        // Close browser
        Thread.sleep(2000);
        wd.quit();
    }

    public static void loginAmazon(WebDriver wd) {
        // Go to the Amazon website
        wd.get("https://www.amazon.in/");

        // Click on the "Account & Lists" link to access the login page
        wd.findElement(By.id("nav-link-accountList")).click();

        // Enter login credentials
        wd.findElement(By.id("ap_email")).sendKeys("ravateshubhangi@gmail.com");
        wd.findElement(By.id("continue")).click();
        wd.findElement(By.id("ap_password")).sendKeys("123456");

        // Click on the "Sign-In" button
        wd.findElement(By.id("signInSubmit")).click();
    }

    public static void registerAmazon(WebDriver wd) {
        // Go to the Amazon website
        wd.get("https://www.amazon.in/");

        // Click on the "Account & Lists" link to access the registration page
        wd.findElement(By.id("nav-link-accountList")).click();

        // Click on the "Create your Amazon account" button
        wd.findElement(By.id("createAccountSubmit")).click();

        // Enter registration details
        wd.findElement(By.id("ap_customer_name")).sendKeys("Rohini");
        wd.findElement(By.id("ap_phone_number")).sendKeys("9146224859");
        wd.findElement(By.id("ap_email")).sendKeys("ravateshubhangi2000@gmail.com");
        wd.findElement(By.id("ap_password")).sendKeys("123456");

        // Click on the "Continue" button to complete registration
        wd.findElement(By.xpath("//*[@id=\"continue\"]")).click();
    }
}
